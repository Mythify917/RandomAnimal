# RandomAnimal
## Python module that shows random images of animals.
---------------------------
## Usage:
```py
import RandomAnimal
"""Get random panda image."""
print(RandomAnimal.panda)
```
## Output:
```
https://i.imgur.com/QEss4La.jpg
```
-------------------------------
## Animals Supported:
* Dog
* Cat
* Bird
* Fox
* Panda
* Koala
<center style="font-size: 200%">
Join the <a href="https://discord.gg/D4NE85WXSM" target="_blank">Discord Server</a> for the latest updates!
</center>