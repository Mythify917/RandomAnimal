from setuptools import setup


setup(name='RandomAnimal',
      version='0.1',
      description='Get random animal photos.',
      url='https://github.com/Mythify917/RandomAnimal',
      author='Mythify',
      author_email='thenoobdude21.12@gmail.com',
      license='MIT',
      packages=[],
      zip_safe=False)
